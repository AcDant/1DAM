import javax.swing.*;
import java.util.ArrayList;

public class User {

    private String name;
    private String email;
    private ArrayList<PlayList> listPL;

    public User(String name, String email) {
        this.name = name;
        this.email = email;
        listPL = new ArrayList<>();
    }

    public PlayList createPlaylist(String plName){
        PlayList pl = new PlayList(plName);
        listPL.add(pl);
        return pl;
    }

    public PlayList findPlaylist(String plName){
        for (int i = 0; i < listPL.size(); i++){
            PlayList atList = listPL.get(i);
            if (atList.getName().equals(plName)){
                return atList;
            }
        }
        return null;
    }

    public void deletePlaylist(String plName){
        int comp = 0;
        for (int i = 0; i < listPL.size(); i++){
            PlayList atList = listPL.get(i);
            if (atList.getName().equals(plName)){
                listPL.remove(i);
                comp = 1;
            }
        }
        if (comp == 1) {
            System.out.println("Se ha eliminado la playlist");
        } else {
            System.out.println("No existe la playlist a borrar");
        }
    }

    public void renamePlaylist(String plName, String newName){
        int comp = 0;
        for (int i = 0; i < listPL.size(); i++){
            PlayList atList = listPL.get(i);
            if (atList.getName().equals(plName)){
                listPL.get(i).setName(newName);
                comp = 1;
            }
        }
        if (comp == 1){
            System.out.println("Nombre cambiado");
        } else {
            System.out.println("No existe la playlist");
        }
    }

    public ArrayList getPlaylistNames(){
        ArrayList<String> plnames = new ArrayList<>();
        for (int i = 0; i < listPL.size(); i++){
            plnames.add(listPL.get(i).getName());
        }
        return plnames;
    }

    public ArrayList getFavouriteBands(){
        ArrayList<String> bdnames = new ArrayList<>();
        for (int i = 0; i < listPL.size(); i++){
            PlayList pl = listPL.get(i);
            for (int j = 0; j < pl.getCount(); j++){
                Song sg = pl.getSong(j);
                if (sg.getPerformer().getClass().equals(Band.class)){
                    String band = sg.getPerformer().getName();
                    int x = 0;
                    for (int k = 0; k < bdnames.size(); k++){
                        if (bdnames.get(k).equals(band)){
                            x++;
                        }
                    }
                    if (x == 0){
                        bdnames.add(band);
                    }
                }
            }
        }
        return bdnames;
    }



}
