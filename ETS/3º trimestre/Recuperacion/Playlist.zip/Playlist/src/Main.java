
public class Main {
    public static void main(String[] args) {

        System.out.println("Generar la documentación del proyecto.");
        System.out.println("Subirá nota crear unas cuantas canciones... solistas, bandas, listas preferidas y búsquedas implementadas....");
        System.out.println("Suerte ...");

    }
}