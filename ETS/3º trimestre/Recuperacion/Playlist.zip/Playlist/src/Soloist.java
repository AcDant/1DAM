public class Soloist extends Performer{

    private Nacionality.nacionality nacionality;
    private String name;

    public Soloist(long id, Nacionality.nacionality nation, String name) {
        super(id);
        this.nacionality = nation;
        this.name = name;
    }


    @Override
    public String getName(){
        return name;
    }

    @Override
    public String toString() {
        return "Soloist{" +
                "nacionality=" + nacionality +
                ", name='" + name + '\'' +
                '}';
    }
}
