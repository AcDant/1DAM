public abstract class Performer {

    private long id;

    public Performer(long id) {
        this.id = id;
    }

    public long getId() {
        return this.id;
    }
    abstract String getName();
}

