public class Nacionality {
    public enum nacionality{spanish, french, germany, americans};
}
