import java.util.Objects;

public class Song {

    private final long id;
    private final String title;
    private final String genre;
    private final Performer performer;

    public Song(long id, String title, String genre, Performer performer) {
        this.id = id;
        this.title = title;
        this.genre = genre;
        this.performer = performer;
    }

    @Override
    public String toString() {
        return "Song{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", genre='" + genre + '\'' +
                ", performer=" + performer +
                '}';
    }

    public boolean equals(Song song) {
        if (this.id == song.id) return true;
        else return false;
    }


    public long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getGenre() {
        return genre;
    }

    public Performer getPerformer() {
        return performer;
    }

    // Aunque los pides, no hay setter ya que son atributos finales.

}
