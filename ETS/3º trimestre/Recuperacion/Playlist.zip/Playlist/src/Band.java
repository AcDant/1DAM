import java.util.ArrayList;

public class Band extends Performer{
    private ArrayList<String> names;
    private String bandname;

    public Band(long id, String name) {
        super(id);
        this.bandname = name;
        names = new ArrayList<>();
    }

    public void setNames(String name) {
        this.names.add(name);
    }

    @Override
    public String getName(){
        return bandname;
    }

    @Override
    public String toString() {
        return "Band{" +
                "names=" + names +
                ", name='" + bandname + '\'' +
                '}';
    }
}
