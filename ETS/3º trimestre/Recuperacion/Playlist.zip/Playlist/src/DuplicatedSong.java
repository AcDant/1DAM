public class DuplicatedSong extends Exception {

    public DuplicatedSong(Song song) {

        super("Ahhhhhh, la canción " + song.getTitle() + " ya se encuentra en nuestra playlist");
    }
}
