import java.util.ArrayList;

public class PlayList {

    private String name;
    private ArrayList<Song> playlist;

    public PlayList(String name) {
        this.name = name;
        playlist = new ArrayList<>();
    }

    public void add(Song song) throws DuplicatedSong {
        for (Song cancion :this.playlist){
            if (song.equals(cancion)){
                throw new DuplicatedSong(song);
            }
        }
        this.playlist.add(song);
    }

    public boolean remove(long idSong){
        for (int i = 0; i < playlist.size(); i++){
            Song atList = playlist.get(i);
            if (atList.getId() == idSong){
                playlist.remove(i);
                return true;
            }
        }
        return false;
    }

    public PlayList find(String titleSong) throws DuplicatedSong {
        PlayList pl = new PlayList("containsTitleSongs");
        for (int i = 0; i < playlist.size(); i++){
            Song atList = playlist.get(i);
            if (atList.getTitle().contains(titleSong)){
                pl.add(atList);
            }
        }
        return pl;
    }

    public Song find(long idSong){
        for (int i = 0; i < playlist.size(); i++){
            Song atList = playlist.get(i);
            if (atList.getId() == idSong) {
                return atList;
            }
        }
        return null;
    }
    public PlayList findCommonSongs(PlayList playListToSearch) throws DuplicatedSong {
        PlayList common = new PlayList("common");
        for (int i = 0; i < playlist.size(); i++){
            Song atList = playlist.get(i);
            if (playListToSearch.find(atList.getId()) != null){
                common.add(atList);
            }
        }
        return common;
    }

    public int getCount(){
        int count = 0;
        for (int i = 0; i < playlist.size(); i++){
            Song atList = playlist.get(i);
            if (atList != null) {
                count++;
            }
        }
        return count;
    }

    public Song getSong(int index){
        if (index>0 && index<playlist.size())
            return playlist.get(index);
        return null;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "PlayList{" +
                "name='" + name + '\'' +
                ", playlist=" + playlist +
                '}';
    }
}
